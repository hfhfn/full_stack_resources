# python3
from information_summary_filter import MemoryFilter
from information_summary_filter  import RedisFilter
from information_summary_filter import MySQLFilter


# filter = MemoryFilter()
# filter = RedisFilter(redis_host="172.17.0.2")
mysql_url = "mysql+pymysql://root:password@172.17.0.4:3306/data?charset=utf8"
filter = MySQLFilter(mysql_url=mysql_url)

data = ["111", "qwe", '222', "333" ,"111", "qwe", "中文", "qwer"]

for d in data:
    if filter.is_exists(d):
        print("发现重复的数据: ", d)
    else:
        filter.save(d)
        print("保存去重的数据：", d)
