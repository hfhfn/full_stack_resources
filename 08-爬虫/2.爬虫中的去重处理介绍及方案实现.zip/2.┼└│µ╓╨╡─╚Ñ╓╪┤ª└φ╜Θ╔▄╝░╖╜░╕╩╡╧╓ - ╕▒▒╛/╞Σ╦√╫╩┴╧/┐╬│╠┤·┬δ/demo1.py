[123, "123", 123, "456", "qwe", "qwe"]
# 需求一：剔除重复数据    ==
result1 = []    # 存储最终结果
sign1 = []
new_data = None   # "123"
if new_data not in sign1:
    sign1.append(new_data)
    result1.append(new_data)
# ["123", 123, "456", "qwe"]


# 需求二：剔除重复数据，同时规定"100"和100是重复的   str()    ==
result2 = []
sign2 = []   # 判断依据  str(原始数据)   去重容器
new_data = None   # "123"
if str(new_data) not in sign2:
    sign2.append(str(new_data))
    result2.append(new_data)
# sign2: ["123", "456", "qwe"]   #
# result2 :  [123, "456", "qwe"]


class Test(object):
    def __init__(self, v):
        self.v = v
t1 = Test(100)
t2 = Test(100)
t3 = Test(200)
t4 = t1
# 需求三：剔除重复数据   ==
data3 = [t1, t2, t3, t4]
set()
result3 = [t1, t2, t3]

# 需求四：剔除重复数据，规定：Test对象的v相同则为重复对象  t.v    ==
data4 = [t1, t2, t3, t4]
sign4 = [100,200]
result4 = [t1, t3]

# 需求五：剔除重复数据，规定：对象的类相同,则表示是重复的对象   t.__class__    ==
data5 = [t1, t2, t3, t4]
sign5 = [Test]
result5 = [t1]




# 判断依据（如何规定两个数据是重复数据）
# 去重容器 （存储判断原始数据的判断依据）

