from redis_tools import get_redis_queue_cls


Queue = get_redis_queue_cls("fifo")

REDIS_QUEUE_CONFIG = {
    "name": "pqueue",
    "host": "172.17.0.2",
    "db": 0,
    "use_lock": False,
    "redis_lock_config": {
        "lock_name":"pqueue-lock",
        "host":"172.17.0.2"
    }
}

pqueue = Queue(**REDIS_QUEUE_CONFIG)


pqueue.put((100, "value100"))

print(pqueue.get())
