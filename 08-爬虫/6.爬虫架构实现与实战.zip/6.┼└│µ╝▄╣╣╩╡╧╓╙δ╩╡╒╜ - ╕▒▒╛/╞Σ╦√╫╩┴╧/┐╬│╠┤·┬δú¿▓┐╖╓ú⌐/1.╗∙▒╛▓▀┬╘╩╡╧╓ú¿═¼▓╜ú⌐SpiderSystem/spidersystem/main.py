from spidersystem.downloader import RequestsDownloader
from spidersystem.request_manager import RequestManager
from spidersystem.request import Request
from spidersystem.response import Response
from spidersystem.request_manager.utils.redis_tools import get_redis_queue_cls


Queue = get_redis_queue_cls("fifo")


class Master(object):

    def __init__(self, spiders, request_queue, request_manager_config):
        self.filter_queue = Queue("filter_queue", host="10.211.55.3")
        self.request_manager = RequestManager(**request_manager_config)
        self.spiders = spiders
        self.request_queue = request_queue

    def run(self):
        for spider in self.spiders.values():
            for r in spider().start_requests():
                self.request_manager.add_request(r, self.request_queue)
        while True:
            for request in self.filter_queue.get():
                self.request_manager.add_request(request, self.request_queue)

class Slave(object):

    def __init__(self, spiders, request_queue, request_manager_config):
        self.filter_queue = Queue("filter_queue", host="10.211.55.3")
        self.request_manager = RequestManager(**request_manager_config)
        self.downloader = RequestsDownloader()
        self.spiders = spiders
        self.request_queue = request_queue

    def run(self):
        while True:
            # 1. 获取请求对象
            request = self.request_manager.get_request(self.request_queue)
            # 2. 发起请求
            response = self.downloader.fetch(request)
            # 3. 处理响应
            spider = self.spiders[request.name]()
            for result in spider.parse(response):
                if result is None:
                    raise Exception("parse方法未返回任何结果")
                elif isinstance(result, Request):
                    self.filter_queue.put(result)
                else:
                    clean_result = spider.data_clean(result)
                    spider.data_save(clean_result)




