import requests

from spidersystem.response import Response


class RequestsDownloader(object):

    def fetch(self, request):
        if request.method.upper() == "GET":
            response = requests.get(request.url_with_query, headers=request.headers)
        elif request.method.upper() == "POST":
            response = requests.get(request.url_with_query, data=request.body, headers=request.headers)
        else:
            raise Exception("Only support GET or POST method ")
        return Response(request=request, status_code=response.status_code, url=response.url, headers=response.headers, body=response.content)
