from spidersystem.request import Request


class BaseSpider(object):
    '''爬虫基类'''

    def start_requests(self):
        yield Request("http://www.example.com")

    def parse(self, response):
        '''生成器'''
        yield

    def data_clean(self, data):
        return data

    def data_save(self, data):
        pass