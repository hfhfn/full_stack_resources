import requests
from tornado.httpclient import HTTPClient, HTTPRequest, AsyncHTTPClient

from spidersystem.response import Response


class RequestsDownloader(object):

    def fetch(self, request):
        if request.method.upper() == "GET":
            response = requests.get(request.url_with_query, headers=request.headers)
        elif request.method.upper() == "POST":
            response = requests.get(request.url_with_query, data=request.body, headers=request.headers)
        else:
            raise Exception("Only support GET or POST method ")
        return Response(request=request, status_code=response.status_code, url=response.url, headers=response.headers, body=response.content)


class TornadoDownloader(object):

    def __init__(self):
        self.httpclient = HTTPClient()

    def fetch(self, request):
        tornado_request = HTTPRequest(request.url_with_query, method=request.method, headers=request.headers)
        response = self.httpclient.fetch(tornado_request)
        return Response(request=request, status_code=response.code, url=response.effective_url, headers=response.headers, body=response.buffer.read())

    def __del__(self):
        self.httpclient.close()


# 使用pycurl，前提必须安装pycurl
AsyncHTTPClient.configure("tornado.curl_httpclient.CurlAsyncHTTPClient")

class AsyncTornadoDownloader(object):

    def __init__(self):
        self.httpclient = AsyncHTTPClient()

    async def fetch(self, request):
        tornado_request = HTTPRequest(request.url_with_query, method=request.method, headers=request.headers)
        response = await self.httpclient.fetch(tornado_request)
        return Response(request=request, status_code=response.code, url=response.effective_url, headers=response.headers, body=response.buffer.read())
