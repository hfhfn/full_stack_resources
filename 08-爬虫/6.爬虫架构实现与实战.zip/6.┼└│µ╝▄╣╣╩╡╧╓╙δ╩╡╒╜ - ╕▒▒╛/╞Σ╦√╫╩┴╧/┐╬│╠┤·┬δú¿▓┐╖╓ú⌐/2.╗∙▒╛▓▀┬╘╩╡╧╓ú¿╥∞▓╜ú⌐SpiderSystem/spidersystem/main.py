import threading
import asyncio
import tornado.ioloop

from spidersystem.downloader import RequestsDownloader, TornadoDownloader, AsyncTornadoDownloader
from spidersystem.request_manager import RequestManager
from spidersystem.request import Request
from spidersystem.request_manager.utils.redis_tools import get_redis_queue_cls

Queue = get_redis_queue_cls("fifo")

class Master(object):

    def __init__(self, spiders, request_queue, request_manager_config):
        self.filter_queue = Queue("filter_queue", host="10.211.55.3")
        self.request_manager = RequestManager(**request_manager_config)
        self.spiders = spiders
        self.request_queue = request_queue

    def run_start_requests(self):
        for spider in self.spiders.values():
            for r in spider().start_requests():
                self.request_manager.add_request(r, self.request_queue)

    def run_filter_request(self):
        while True:
            for request in self.filter_queue.get():
                self.request_manager.add_request(request, self.request_queue)

    def run(self):
        # self.run_start_requests()
        # self.run_filter_request()
        threading.Thread(target=self.run_start_requests).start()
        threading.Thread(target=self.run_filter_request).start()


class Slave(object):

    def __init__(self, spiders, request_queue, request_manager_config):
        self.filter_queue = Queue("filter_queue", host="10.211.55.3")
        self.request_manager = RequestManager(**request_manager_config)
        self.downloader = AsyncTornadoDownloader()
        self.spiders = spiders
        self.request_queue = request_queue

    async def handle_request(self):
        io_loop = tornado.ioloop.IOLoop.current()
        # 1. 获取请求对象
        future = io_loop.run_in_executor(None, self.request_manager.get_request, self.request_queue)
        request = await future
        # 2. 发起请求
        response = await self.downloader.fetch(request)
        # 3. 处理响应
        spider = self.spiders[request.name]()
        for result in spider.parse(response):
            if result is None:
                raise Exception("parse方法未返回任何结果")
            elif isinstance(result, Request):
                await io_loop.run_in_executor(None, self.filter_queue.put, result)
                # self.filter_queue.put(result)
            else:
                clean_result = spider.data_clean(result)
                spider.data_save(clean_result)

    async def run(self):

        while True:
            await asyncio.wait([self.handle_request(),
                                self.handle_request()])
