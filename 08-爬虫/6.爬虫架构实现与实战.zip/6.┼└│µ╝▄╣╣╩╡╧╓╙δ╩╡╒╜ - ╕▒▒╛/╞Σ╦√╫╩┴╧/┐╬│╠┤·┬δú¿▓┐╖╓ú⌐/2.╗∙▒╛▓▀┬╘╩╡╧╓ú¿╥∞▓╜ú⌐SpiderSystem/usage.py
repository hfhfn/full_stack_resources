
from spidersystem.spider import BaseSpider
from spidersystem.request import Request
from spidersystem.main import Master, Slave


REQUEST_MANAGER_CONFIG = {
    "queue_type": "fifo",
    # 如何配置需查看redis队列的实例化时需要的参数  redis_queue模块中
    # 注意：redis的key会被queue_name重写，因此此处不用写
    "queue_kwargs": {"host":"10.211.55.3", "port":6379},

    "filter_type": "redis",
    # 如何配置需查看对应过滤器实例化时如何传参   filter_class模块中
    # 注意：redis的key或mysql的表名称 会被filter_name重写，因此此处不用写
    "filter_kwargs": {"redis_key":"redis_filter", "redis_host":"10.211.55.3"},
}

REQUEST_QUEUE = "request_queue"

class BaiduSpider(BaseSpider):

    name = "baidu"

    def start_requests(self):
        yield Request("http://www.baidu.com", name=self.name)
        yield Request("http://www.baidu.com/s?wd=python", name=self.name)
        yield Request("http://www.baidu.com/s?wd=python2", name=self.name)
        yield Request("http://www.baidu.com/s?wd=python3", name=self.name)
        yield Request("http://www.baidu.com/s?wd=python4", name=self.name)

    def parse(self, response):
        print(response)
        print(response.url)
        yield response.url


if __name__ == '__main__':
    spiders = {BaiduSpider.name: BaiduSpider}
    # Master(spiders, request_queue=REQUEST_QUEUE,  request_manager_config=REQUEST_MANAGER_CONFIG).run()


    slave = Slave(spiders, request_queue=REQUEST_QUEUE,  request_manager_config=REQUEST_MANAGER_CONFIG)
    import tornado.ioloop

    io_loop = tornado.ioloop.IOLoop.current()
    io_loop.run_sync(slave.run)

