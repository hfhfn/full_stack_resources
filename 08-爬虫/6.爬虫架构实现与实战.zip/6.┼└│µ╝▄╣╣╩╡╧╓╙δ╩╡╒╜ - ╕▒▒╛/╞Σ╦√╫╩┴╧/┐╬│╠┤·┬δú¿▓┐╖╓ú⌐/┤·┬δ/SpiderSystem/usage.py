
import tornado.ioloop
from spidersystem.main import Master, Slave
from spidersystem.request import Request
from spidersystem.spider import BaseSpider


REQUEST_MANAGER_CONFIG = {
    "queue_type": "fifo",
    # 如何配置需查看redis队列的实例化时需要的参数  redis_queue模块中
    # 注意：redis的key会被queue_name重写，因此此处不用写
    "queue_kwargs": {"host":"10.211.55.3", "port":6379},

    "filter_type": "bloom",
    # 如何配置需查看对应过滤器实例化时如何传参   filter_class模块中
    # 注意：redis的key或mysql的表名称 会被filter_name重写，因此此处不用写
    "filter_kwargs": {"redis_key":"redis_filter", "redis_host":"10.211.55.3", "salts": ["a", "b", "c", "d"]},
}


PROJECT_NAME = "baidu"

class BaiduSpider(BaseSpider):

    name = 'baidu'

    def start_requests(self):
        '''生成器'''
        yield Request("http://www.baidu.com", name=self.name)
        yield Request("http://www.baidu.com/s?wd=python", name=self.name)
        yield Request("http://www.baidu.com/s?wd=python2", name=self.name)
        yield Request("http://www.baidu.com/s?wd=python3", name=self.name)
        yield Request("http://www.baidu.com/s?wd=python4", name=self.name)
        yield Request("http://www.baidu.com/s?wd=python5", name=self.name)

    def parse(self, response):
        '''生成器'''
        print(response)
        print(response.url)
        yield response.body

    def data_clean(self, data):
        return data

    def data_save(self, data):
        pass



if __name__ == '__main__':
    spiders = {BaiduSpider.name: BaiduSpider}
    Master(spiders, project_name=PROJECT_NAME, request_manager_config=REQUEST_MANAGER_CONFIG).run()

    # slave = Slave(spiders, project_name=PROJECT_NAME, request_manager_config=REQUEST_MANAGER_CONFIG)

    # io_loop = tornado.ioloop.IOLoop.current()
    # io_loop.run_sync(slave.run)


