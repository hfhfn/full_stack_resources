from confluent_kafka import Consumer, KafkaError, TopicPartition


from wxpy import *
# 先用其他小号登录微信
bot = Bot(console_qr=True)
# 指明要将消息发给谁
# search第一个参数表示 对方的微信昵称
friend = bot.friends().search("低调程序员的小号")[0]     # 注意下标，如果没有此人，此处会报错


c = Consumer({
    'bootstrap.servers': '10.211.55.3:29092',
    'group.id': 'mygroup',
    'default.topic.config': {
        'auto.offset.reset': 'smallest'   # largest
    }
})

c.subscribe(['mytopic2'])

while True:
    msg = c.poll(1.0)
    if msg is None:
        continue

    if msg.error():
        if msg.error().code() == KafkaError._PARTITION_EOF:
            continue
        else:
            print(msg.error())
            break

    friend.send(msg.value())

    print('Received message: {} {} {}'.format(msg.value().decode('utf-8'), msg.topic(), msg.partition()))

c.close()


if __name__ == '__main__':
    pass