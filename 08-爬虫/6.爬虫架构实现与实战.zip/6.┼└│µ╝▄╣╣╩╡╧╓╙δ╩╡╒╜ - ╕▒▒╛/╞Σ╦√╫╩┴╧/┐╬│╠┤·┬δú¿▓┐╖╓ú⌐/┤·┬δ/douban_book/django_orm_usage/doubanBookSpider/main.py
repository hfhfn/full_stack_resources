import os
# os.system("python manage.py makemigrations spider")
# os.system("python manage.py migrate spider")

# os.system("python manage.py run_master")
os.system("python manage.py run_slave")