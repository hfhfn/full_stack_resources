from spidersystem.request import Request
from spidersystem.spider import BaseSpider

from spider.models import BigTag, SmallTag, Book

class TagsSpider(BaseSpider):

    name = "tags-spider"

    def start_requests(self):
        tag_list_url = "https://book.douban.com/tag/?view=type&icn=index-sorttags-hot"
        yield Request(tag_list_url, name=self.name)

    def parse(self, response):
        for div in response.xpath("//div[@class='article']/div[2]/div"):
            big_tag = div.xpath("./a/@name")
            small_tags = div.xpath("./table//td/a/text()")
            yield big_tag, small_tags

    def data_clean(self, data):
        return data

    def data_save(self, data):
        bt, st = data
        if not BigTag.objects.filter(btag=bt[0]):
            big_tag = BigTag(btag=bt[0])
            big_tag.save()
            for t in st:
                small_tag = SmallTag(stag=t, btag=big_tag)
                small_tag.save()


