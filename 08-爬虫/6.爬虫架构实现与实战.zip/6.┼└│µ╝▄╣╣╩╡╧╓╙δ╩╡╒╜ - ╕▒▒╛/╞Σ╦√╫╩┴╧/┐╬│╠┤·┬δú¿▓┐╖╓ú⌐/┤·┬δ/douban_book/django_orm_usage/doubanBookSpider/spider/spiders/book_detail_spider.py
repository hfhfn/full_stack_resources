import re
from datetime import datetime

from spidersystem.request import Request
from spidersystem.spider import BaseSpider

from spider.models import BigTag, SmallTag, Book

class BookDetailSpider(BaseSpider):
    name = "book-detail-spider"

    # book info中的所有字段
    book_info_details = [("作者", "author"),
                         ("出版社", "publisher"),
                         ("出品方", "producer"),
                         ("原作名", "original_title"),
                         ("译者", "translator"),
                         ("出版年", "publish_time"),
                         ("页数", "page_number"),
                         ("定价", "price"),
                         ("装帧", "pack"),
                         ("丛书", "series"),
                         ("ISBN", "isbn"),
                         ("副标题", "subtitle")]

    def start_requests(self):
        return []

    def parse(self, response):
        '''生成器'''
        # info内的标签没有规则，xpath很难定位
        info_text_list = response.xpath("//div[@id='info']//text()")
        # 使用正则来处理
        info_str = "".join(info_text_list)  # 全部拼接为字符串
        info_str = re.sub(r"\s", "", info_str)  # 剔除空白字符
        info_str = re.sub(r"\xa0", "", info_str)  # 剔除无用字符

        detail = {}

        # 筛选出info中每一个字段的值
        for filed, filed_name in self.book_info_details:
            # 挨个筛选出字段，如 '作者:[日]东野圭吾出版社'
            ret = re.search("%s:(.*?):" % filed, info_str + ":")
            if ret:
                # 剔除掉 '作者:[日]东野圭吾出版社'末尾的'出版社'，其他同理
                value = re.sub("(作者|出版社|出品方|原作名|译者|出版年|页数|定价|装帧|丛书|ISBN|副标题)$", "", ret.group(1))
                detail[filed_name] = value
            else:
                detail[filed_name] = None

        # 选取标题
        book_title = response.xpath("//div[@id='wrapper']/h1/span/text()")
        detail["title"] = book_title

        # 评分：
        rating_num = response.xpath("//div[@id='interest_sectl']//strong/text()")
        detail["rating_num"] = rating_num

        # 内容简介
        book_summary = response.xpath(
            "//div[@class='related_info']/div[@class='indent'][1]//div[@class='intro']//text()")
        detail["book_summary"] = book_summary

        # 作者简介
        # 注意indent后面那个神奇的空格
        author_summary = response.xpath(
            "//div[@class='related_info']/div[@class='indent ']//div[@class='intro']//text()")
        detail["author_summary"] = author_summary

        yield detail

    def data_clean(self, data):
        '''
                {
                  "author": str,
                  "publisher": str,
                  "producer": str,
                  "original_title": str,
                  "translator": str,
                  "publish_time": datetime,
                  "page_number": int,
                  "price": float,
                  "pack": str,
                  "series": str,
                  "isbn": str/long int,
                  "subtitle": str,
                  "title": str,
                  "rating_num": float,
                  "book_summary": text,
                  "author_summary": text
                }
                '''
        # 1. 数据去重，略
        # 可直接根据ISBN值进行比对，方案较多

        # 2. 数据格式清洗
        _ = data["publish_time"].split("-")
        if len(_) is 1:
            dt = datetime(int(_[0]), 1, 1)
        elif len(_) is 2:
            dt = datetime(int(_[0]), int(_[1]), 1)
        elif len(_) is 3:
            dt = datetime(int(_[0]), int(_[1]), int(_[2]))
        else:
            raise Exception("Can't trans %s to datetime" % data["publish_time"])
        data["publish_time"] = dt.strftime("%Y-%m-%d")

        data["page_number"] = int(data["page_number"])

        data["price"] = float(re.search(r"\d+\.\d+", data["price"]).group())

        data["title"] = data["title"][0].strip()

        data["rating_num"] = float(data["rating_num"][0])

        data["book_summary"] = "".join([i.strip() for i in data["book_summary"]])

        data["author_summary"] = "".join([i.strip() for i in data["author_summary"]])

        # 3. 空值赋值/ 是否需要赋值，看需求
        # 略

        return data

    def data_save(self, data):
        book = Book(**data)
        book.save()



