from django.core.management.base import BaseCommand

from spidersystem.main import Master, Slave
from spider.spiders.book_detail_spider import BookDetailSpider
from spider.spiders.book_list_spider import BookListSpider
from spider.spiders.tags_spider import TagsSpider


PROJECT_NAME = "douban_book"

REQUEST_MANAGER_CONFIG = {
    "queue_type": "fifo",
    # 如何配置需查看redis队列的实例化时需要的参数  redis_queue模块中
    # 注意：redis的key会被queue_name重写，因此此处不用写
    "queue_kwargs": {"host":"10.211.55.3", "port":6379},

    "filter_type": "bloom",
    # 如何配置需查看对应过滤器实例化时如何传参   filter_class模块中
    # 注意：redis的key或mysql的表名称 会被filter_name重写，因此此处不用写
    "filter_kwargs": {"redis_key":"redis_filter", "redis_host":"10.211.55.3", "salts": ["a", "b", "c", "d"]},
}

class Command(BaseCommand):
    help = 'run master'

    def handle(self, *args, **options):
        spiders = {
            TagsSpider.name: TagsSpider,
            BookListSpider.name: BookListSpider,
            BookDetailSpider.name: BookDetailSpider
        }
        Master(spiders, project_name=PROJECT_NAME, request_manager_config=REQUEST_MANAGER_CONFIG).run()

