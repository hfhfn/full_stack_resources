from spidersystem.request import Request
from spidersystem.spider import BaseSpider

from spider.models import BigTag, SmallTag, Book
from .book_detail_spider import BookDetailSpider

class BookListSpider(BaseSpider):

    name = "book-list-spider"

    base_url = "https://book.douban.com/tag/{tag_name}"

    query = {
        "start": 0,
        "type": "T"
    }

    end_offset = 80  #980

    def start_requests(self):
        for stag in SmallTag.objects.all():
            tag_name = stag.stag
            url = self.base_url.format(tag_name=tag_name)
            yield Request(url, query=self.query, name=self.name)
            break

    def parse(self, response):
        book_url_list = response.xpath("//ul[@class='subject-list']/li/div[@class='pic']/a/@href")

        for detail_url in book_url_list:
            yield Request(detail_url, name=BookDetailSpider.name)

        next = response.xpath("//span[@class='next']/a/@href")
        if next and response.request.query["start"] < self.end_offset:
            next_request = response.request
            next_request.query["start"] += 20
            yield next_request

    def data_clean(self, data):
        return data

    def data_save(self, data):
        pass
