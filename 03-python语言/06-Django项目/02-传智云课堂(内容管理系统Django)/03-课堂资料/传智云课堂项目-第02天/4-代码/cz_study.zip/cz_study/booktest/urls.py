from django.conf.urls import url, include
from rest_framework_mongoengine.routers import SimpleRouter
from booktest.views import BookInfoViewSet, HeroInfoViewSet


# 实例化router
router = SimpleRouter()
# 注册视图集
router.register('book', BookInfoViewSet)
router.register('hero', HeroInfoViewSet)


urlpatterns = [
    url(r'test/', include(router.urls)),
]

