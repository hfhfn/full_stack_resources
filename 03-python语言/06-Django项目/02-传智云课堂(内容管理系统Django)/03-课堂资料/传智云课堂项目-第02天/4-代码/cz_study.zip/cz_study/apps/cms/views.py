from rest_framework_mongoengine.viewsets import GenericViewSet, ModelViewSet
from rest_framework.mixins import ListModelMixin
from cms.models import CmsSite, CmsTemplate, CmsPage
from cms.serializers import CmsSiteSerializer, CmsTemplateSerializer, CmsPageSerializer
from common import exceptions, response_code, paginations


class CmsSiteViewSet(ListModelMixin, GenericViewSet):
    queryset = CmsSite.objects
    serializer_class = CmsSiteSerializer


class CmsTemplateViewSet(ListModelMixin, GenericViewSet):
    queryset = CmsTemplate.objects
    serializer_class = CmsTemplateSerializer


class CmsPageViewSet(ModelViewSet):
    queryset = CmsPage.objects
    serializer_class = CmsPageSerializer
    pagination_class = paginations.PathPagePagination
    lookup_field = 'id'
    lookup_url_kwarg = 'page_id'

    # 根据查询参数过滤查询集
    def filter_queryset(self, queryset):
        filters = {}
        # 精确匹配条件检查
        if self.request.query_params.get('siteId'):
            filters.update({'siteId': self.request.query_params.get('siteId')})
        if self.request.query_params.get('templateId'):
            filters.update({'templateId': self.request.query_params.get('templateId')})
        if self.request.query_params.get('pageType'):
            filters.update({'pageType': self.request.query_params.get('pageType')})
        # 模糊匹配条件检查
        if self.request.query_params.get('pageAlias'):
            filters.update({'pageAlias__contains': self.request.query_params.get('pageAlias')})
        if self.request.query_params.get('pageName'):
            filters.update({'pageName__contains': self.request.query_params.get('pageName')})
        if filters:
            queryset = queryset.filter(**filters)
        return queryset

    def create(self, request, *args, **kwargs):
        # 检查唯一索引-siteId,pageWebPath,pageName三者的组合是否已经存在，存在就报错，否则创建
        queryset = self.get_queryset()
        filter_set = queryset.filter(pageWebPath=request.data.get('pageWebPath'), siteId=request.data.get('siteId'),
                                     pageName=request.data.get('pageName'))
        if filter_set:
            exceptions.cast_exception(response_code.CMS_ADDPAGE_EXISTS)
        return super().create(request, *args, **kwargs)

    def destroy(self, request, *args, **kwargs):
        response = super().destroy(request, *args, **kwargs)
        # 修改destroy状态码为接口要求的200
        response.status_code = 200
        return response
