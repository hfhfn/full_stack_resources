from django.conf.urls import url
from cms.views import CmsSiteViewSet, CmsTemplateViewSet, CmsPageViewSet


urlpatterns = [
    url(r'^cms/site/list', CmsSiteViewSet.as_view({'get': 'list'})),
    url(r'^cms/template/list', CmsTemplateViewSet.as_view({'get': 'list'})),
    url(r'^cms/page/add', CmsPageViewSet.as_view({'post': 'create'})),
    url(r'^cms/page/list/(?P<page>\d+)/(?P<size>\d+)', CmsPageViewSet.as_view({'get': 'list'})),
    url(r'^cms/page/get/(?P<page_id>\w+)', CmsPageViewSet.as_view({'get': 'retrieve'})),
    url(r'^cms/page/edit/(?P<page_id>\w+)', CmsPageViewSet.as_view({'put': 'update'})),
    url(r'^cms/page/del/(?P<page_id>\w+)', CmsPageViewSet.as_view({'delete': 'destroy'})),
]
