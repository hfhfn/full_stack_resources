from kombu import Queue, Exchange
import os
from cz_study import settings
# 指定rabbitmq作为celery的队列
BROKER_URL = "amqp://test:test@2018@172.17.0.98:5672//"

CELERY_QUEUES = (
    Queue(settings.QUEUE_CMS_POST_PAGE,
          exchange=Exchange(settings.EX_CMS_POST_PAGE, 'direct'),
          routing_key=settings.ROUTING_KEY_CMS_POST_PAGE),
)
CELERY_ROUTES = {
    'post_page': {
        'queue': settings.QUEUE_CMS_POST_PAGE,
        'routing_key': settings.ROUTING_KEY_CMS_POST_PAGE
    },
}
