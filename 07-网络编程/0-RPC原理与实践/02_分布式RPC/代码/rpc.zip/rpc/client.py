from services import ClientStub
from services import Channel
from services import InvalidOperation
from services import DistributedChannel
import time

# 创建与服务器的连接
# channel = Channel('127.0.0.1', 8000)
channel = DistributedChannel()

# 进行调用
for i in range(50):
    try:
        # 创建用于RPC调用的工具
        stub = ClientStub(channel)
        val = stub.divide(i*100, 50)
        # val = stub.divide(i*100)
        # val = stub.divide(i*100, 0)
    except InvalidOperation as e:
        print(e.message)
    else:
        print(val)

    time.sleep(1)