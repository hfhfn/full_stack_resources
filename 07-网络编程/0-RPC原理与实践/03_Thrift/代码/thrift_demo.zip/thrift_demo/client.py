import sys
sys.path.append('gen-py')

from thrift.transport import TSocket, TTransport
from thrift.protocol import TCompactProtocol
from calculate import Calculate
from base.ttypes import InvalidOperation, Work, Operation


def main():
    # 创建传输工具对象
    transport = TSocket.TSocket('127.0.0.1', 8888)
    transport = TTransport.TBufferedTransport(transport)

    # 创建消息协议工具对象
    protocol = TCompactProtocol.TCompactProtocol(transport)

    # 创建用于进行RPC调用的客户端对象
    client = Calculate.Client(protocol)

    # 进行具体的过程调用
    # 打开连接
    transport.open()

    client.ping()
    print('调用了ping')

    result = client.divide(100, 50)
    print('100 / 50 = {}'.format(result))

    try:
        result = client.divide(100, 0)
    except InvalidOperation as e:
        print(e.why)

    work = Work()
    work.num1 = 100
    work.num2 = 20
    work.op = Operation.ADD
    result = client.calculate(work)
    print('100 + 20 = {}'.format(result))

    work.op = Operation.SUBTRACT
    result = client.calculate(work)
    print('100 - 20 = {}'.format(result))

    # 关闭
    transport.close()


if __name__ == '__main__':
    main()