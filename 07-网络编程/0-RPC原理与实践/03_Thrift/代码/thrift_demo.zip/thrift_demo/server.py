import sys
sys.path.append('gen-py')

from calculate import Calculate
from base.ttypes import InvalidOperation, Operation
from thrift.protocol import TCompactProtocol
from thrift.transport import TSocket, TTransport
from thrift.server import TServer


# 实现接口服务方法的具体代码
class CalculateHandle(Calculate.Iface):
    def ping(self):
        print('ping()')

    def divide(self, num1, num2):
        if num2 == 0:
            raise InvalidOperation(0, 'cannot divide by 0')
        return num1 / num2

    def calculate(self, w):
        if w.op == Operation.ADD:
            return w.num1 + w.num2
        elif w.op == Operation.SUBTRACT:
            return w.num1 - w.num2
        elif w.op == Operation.MULTIPLY:
            return w.num1 * w.num2
        else:
            raise InvalidOperation(w.op, 'invalid operation')


if __name__ == '__main__':
    # 开启服务器，对外提供RPC远程调用服务
    # 构建rpc调用处理工具
    handler = CalculateHandle()
    processor = Calculate.Processor(handler)

    # 构建消息协议工具
    pfactory = TCompactProtocol.TCompactProtocolFactory()

    # 构建传输工具
    transport = TSocket.TServerSocket('127.0.0.1', 8888)
    tfactory = TTransport.TBufferedTransportFactory()

    # 构建服务器对象
    server = TServer.TThreadPoolServer(processor, transport, tfactory, pfactory)

    # 开启服务器
    print('服务器已开启')
    server.serve()