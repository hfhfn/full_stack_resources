const i32 INTCONSTANT = 1234
const map<string,string> MAPCONSTANT = {'hello':'thrift', 'itcast':'python'}

// 定义了一个Operation的枚举
enum Operation {
  ADD = 1,
  SUBTRACT = 2,
  MULTIPLY = 3,
}

# 定义了一个Work的结构体
struct Work {
  1: i32 num1 = 0,
  2: i32 num2,
  3: Operation op,
  4: optional string comment,
}

/*
*  定义了一个InvalidOperation的异常
*  whatOp 表示是哪种Operation的操作
*  why 表示异常的原因
* */
exception InvalidOperation {
  1: i32 whatOp,
  2: string why
}

service BasicService {
    double divide(1:i32 num1, 2:i32 num2) throws (1:InvalidOperation e)
    oneway void ping()
}
